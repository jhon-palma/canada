function ajax_get_contract(contract_id){
    if (contract_id != ''){
        $.ajax({
            method: 'GET',
            url: '/api/contracts/'+ contract_id,
        }).done(function(contract){
            for (var i = 0; i < contract.length; i++) {
                $('#id_contrato').val(contract[i].pk)
                $('#numero_partida').val(contract[i].fields.numero_partida)
                $('#precio_propiedad').val(contract[i].fields.precio_cantidad)
                $('#precio_moneda').val(contract[i].fields.precio_moneda)
                $('#comision_porcentaje').val(contract[i].fields.comision_porcentaje)
                propietarios = contract[i].fields.codigo_propietario.split(',')
                setMultiSelect('propietario', propietarios)
                saveMultiSelect('propietario','propietarios')
                fijarValorSelect('tipo_negocio',contract[i].fields.tipo_negocio)
                fijarValorSelect('tipo_contrato',contract[i].fields.tipo_contrato)
                $('#fecha_inicio').val(contract[i].fields.fecha_inicio)
                $('#fecha_expiracion').val(contract[i].fields.fecha_fin)
            }
        });
    }else{
        $('#form-propiedad')[0].reset();
    }
}


function ajax_check_code_property(code){
    $.ajax({
        method: 'PUT',
        url: '/propiedades/check/property_code/' + code,
    }).done(function(msg) {
        if (msg == 'exists') {
            var str = $("#codigo_remax").val();
            var ultimo = str.length - 1;
            var res = str.substring(0, ultimo);
            $('#codigo_remax').val(res);
            mensagesError('EL CODIGO REMAX ' + code, 'Ya', 'Existe en otra PROPIEDAD.');
        }
    });
}

