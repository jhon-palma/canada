

//Initialise Bootstrap Carousel Touch Slider
// Curently there are no option available.


$( '#bootstrap-touch-slider' ).bsTouchSlider();